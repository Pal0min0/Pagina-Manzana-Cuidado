# MANZANASANB
*Pasos para abrir*
en la carpeta /FRONTEND/ abrir una terminal y colocar: "npm install" despues "npm start" .
en la carpeta /BACKEND/ abrir una terminal y colocar: "npm install" despues "npm run prueba" .