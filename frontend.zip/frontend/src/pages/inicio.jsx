import React from 'react'
import '../assets/css/inicio.css'
import { Link } from 'react-router-dom' 

import instagram from '../assets/img/2111463.png'
import facebook from '../assets/img/5968764.png'
import bienestar from '../assets/img/bann-que-son-descrip-3_.jpg'
import educacion from '../assets/img/bann-que-son-descrip_.jpg'
import emprendimiento from '../assets/img/claudia.png'
import logo from '../assets/img/download-removebg-preview.png'

function Inicio() {
  // Función para hacer scroll suave a una sección
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
      });
    }
  };

  return (
  <div className="Iniciobody">
  <header className="site-header">
    <div className="navbar-container">
      <div className="logo">
        <img src={logo} alt="Logo Manzanas del Cuidado" />
        <h1>Manzanas del Cuidado</h1>
      </div>
      <nav className="navbar-links">
        <button onClick={() => scrollToSection('hero')}>Inicio</button>
        <button onClick={() => scrollToSection('servicios')}>Servicios</button>
        <button onClick={() => scrollToSection('manzanas')}>Manzanas</button>
        <button onClick={() => scrollToSection('nosotros')}>Nosotros</button>
        <button onClick={() => scrollToSection('contacto')}>Contacto</button>
        <Link to="/ingresar" className="btn-small">Ingresar</Link>
        <Link to="/registrarse" className="btn-small btn-outline">Registrarse</Link>
      </nav>
    </div>
  </header>

  <section id="hero" className="hero-center">
    <h2>Apoyo a Mujeres Cuidadoras</h2>
    <p>Espacios gratuitos para el bienestar, desarrollo y autocuidado.</p>
    <div className="hero-actions">
      <button onClick={() => scrollToSection('servicios')}>Conoce los servicios</button>
      <button onClick={() => scrollToSection('manzanas')}>Ubícanos</button>
    </div>
  </section>

  <section id="servicios" className="services-section">
    <h2>Nuestros Servicios</h2>
    <div className="services-grid">
      <div className="service-item">
        <img src={educacion} alt="Educación" />
        <h3>Educación</h3>
        <p>Finaliza tus estudios o prepárate profesionalmente.</p>
      </div>
      <div className="service-item">
        <img src={emprendimiento} alt="Emprendimiento" />
        <h3>Emprendimiento</h3>
        <p>Apoyo para tus ideas de negocio o crecimiento empresarial.</p>
      </div>
      <div className="service-item">
        <img src={bienestar} alt="Bienestar" />
        <h3>Bienestar</h3>
        <p>Espacios recreativos, culturales y deportivos para ti.</p>
      </div>
    </div>
  </section>

  <section id="manzanas" className="map-section-alt">
    <h2>Encuentra tu Manzana del Cuidado</h2>
    <div className="map-wrapper">
      <iframe src="https://www.google.com/maps/embed?..."></iframe>
    </div>
    <div className="map-info">
      <h3>Ubicación Central</h3>
      <p>Cra. 6 #14-98 Piso 4, Santa Fé, Bogotá</p>
      <p>Oficina del Gobierno del Distrito</p>
    </div>
  </section>

  <section id="nosotros" className="about-split">
    <div className="about-text">
      <h2>Nosotros</h2>
      <h3>Misión</h3>
      <p>Apoyar a las mujeres cuidadoras con servicios gratuitos y bienestar.</p>
      <h3>Visión</h3>
      <p>Construir redes que dignifiquen el trabajo del cuidado en Bogotá.</p>
    </div>
    <div className="about-image">
      <img src={bienestar} alt="Imagen sobre bienestar" />
    </div>
  </section>

  <section id="contacto" className="contacto-simple">
    <h2>Contacto</h2>
    <div className="contact-columns">
      <div className="contact-details">
        <p>📍 Alcaldía de Bogotá, Distrito Capital</p>
        <p>📞 +57 123 456 7890</p>
        <p>✉️ manzanascuidadoBG@bogota.gov.co</p>
        <p>🕐 Lunes a Viernes: 6:00 AM - 7:00 PM</p>
      </div>
      <div className="contact-social">
        <h3>Redes Sociales</h3>
        <a href="https://www.facebook.com/groups/350023832768158"><img src={facebook} alt="Facebook" /></a>
        <a href="https://www.instagram.com/"><img src={instagram} alt="Instagram" /></a>
      </div>
    </div>
  </section>

  <footer className="footer-minimal">
    <p>&copy; 2025 Manzanas del Cuidado. Todos los derechos reservados.</p>
    <nav className="footer-nav">
      <Link to="/">Privacidad</Link>
      <Link to="/">Términos</Link>
      <Link to="/">Mapa del Sitio</Link>
    </nav>
  </footer>
</div>

);
}

export default Inicio

